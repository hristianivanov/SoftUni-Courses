﻿namespace Raiding.Exceptions
{
    public static class ExceptionMessages
    {
        public const string InvalidHeroTypeExceptionMessage =
            "Invalid hero!";
    }
}
