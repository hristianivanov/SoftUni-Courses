﻿namespace PlanetWars.Models.MilitaryUnits
{
    public class StormTroopers : MilitaryUnit
    {
        public StormTroopers(double cost) 
            : base(2.5)
        {
        }
    }
}
