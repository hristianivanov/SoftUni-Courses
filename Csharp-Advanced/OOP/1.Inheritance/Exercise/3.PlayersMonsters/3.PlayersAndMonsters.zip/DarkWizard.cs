﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3.PlayersMonsters
{
    public class DarkWizard : Wizard
    {
        public DarkWizard(string username, int level) : base(username, level)
        {
        }
    }
}
