﻿namespace CollectionHierarchy.Interfaces
{
    public interface IMyList : IAddRemover
    {
        int Used { get; }
    }
}
