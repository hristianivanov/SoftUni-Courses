﻿namespace MilitaryElite.Models.Enums
{
    public enum State
    {
        inProgress,
        Finished
    }
}
