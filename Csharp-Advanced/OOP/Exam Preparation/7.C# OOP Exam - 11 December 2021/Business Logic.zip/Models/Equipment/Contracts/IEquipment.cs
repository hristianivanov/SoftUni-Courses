﻿namespace Gym.Models.Equipment.Contracts
{
    public interface IEquipment
    {
        double Weight { get; }
        decimal Price { get; }
    }
}
