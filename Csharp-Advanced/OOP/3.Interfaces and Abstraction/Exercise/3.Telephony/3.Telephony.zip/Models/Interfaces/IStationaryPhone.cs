﻿namespace Telephony.Models.Interfaces
{
    public interface IStationaryPhone
    {
        public void Call(string phoneNumber);
    }
}