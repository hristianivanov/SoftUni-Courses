﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2.Zoo
{
    public class Mammal : Animal
    {
        public Mammal(string name) : base(name)
        {
        }
    }
}
