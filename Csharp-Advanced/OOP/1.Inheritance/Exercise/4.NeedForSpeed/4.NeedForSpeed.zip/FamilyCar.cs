﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4.NeedForSpeed
{
    public class FamilyCar : Car
    {
        public FamilyCar(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
    }
}
