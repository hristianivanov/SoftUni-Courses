﻿
namespace Cars
{
     interface IElectricCar
    {
        int Battery { get; set; }
    }
}
