﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _6.SpeedRacing
{
    public class Program
    {
        static void Main(string[] args)
        {
            //"{model} {fuelAmount} {fuelConsumptionFor1km}"
            List<Car> cars = new List<Car>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                var carProps = Console.ReadLine().Split();
                Car car = new Car(carProps[0], double.Parse(carProps[1]), double.Parse(carProps[2]));
                cars.Add(car);
            }
            string input = string.Empty;
            while ((input = Console.ReadLine())!="End")
            {
                //Drive { carModel} { amountOfKm}
                string[] splitted = input.Split(' ',StringSplitOptions.RemoveEmptyEntries);
                if (splitted[0]=="Drive")
                {
                    Car car = cars.FirstOrDefault(x => x.Model == splitted[1]);
                    car.Drive(car, int.Parse(splitted[2]));
                }
            }
            cars.ForEach(car => Console.WriteLine($"{car.Model} {car.FuelAmount:f2} {car.TravelledDistance}"));
        }
    }
}
