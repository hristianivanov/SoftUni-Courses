﻿namespace CollectionHierarchy.Interfaces
{
    public interface IAddder
    {
        int Add(string item);
    }
}
