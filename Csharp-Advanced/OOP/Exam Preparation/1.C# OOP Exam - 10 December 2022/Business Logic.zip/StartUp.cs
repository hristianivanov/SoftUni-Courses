﻿namespace ChristmasPastryShop
{
    using Core;
    using Core.Contracts;
    using System.Collections.Generic;
    using System.Linq;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            IEngine engine = new Engine();
            engine.Run();
        }
    }
}
