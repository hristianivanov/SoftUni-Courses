window.addEventListener("load", solve);

//TODO