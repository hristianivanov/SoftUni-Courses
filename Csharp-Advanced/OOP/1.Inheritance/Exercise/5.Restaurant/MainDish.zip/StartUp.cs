﻿using System;
using _5.Restaurant;

namespace Restaurant
{
    public class StartUp
    {
        static void Main(string[] args)
        {
           
        }
    }
}
