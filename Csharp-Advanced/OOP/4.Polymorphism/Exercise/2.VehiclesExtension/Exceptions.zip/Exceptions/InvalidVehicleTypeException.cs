﻿using System;
using System.Runtime.Serialization;

namespace VehiclesExtension.Exceptions
{
    [Serializable]
    internal class InvalidVehicleTypeException : Exception
    {
        public InvalidVehicleTypeException()
        {
        }

        public InvalidVehicleTypeException(string message) : base(message)
        {
        }

        public InvalidVehicleTypeException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidVehicleTypeException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}