﻿namespace PlanetWars.Models.MilitaryUnits
{
    public class AnonymousImpactUnit : MilitaryUnit
    {
        public AnonymousImpactUnit(double cost) 
            : base(30)
        {
        }
    }
}
