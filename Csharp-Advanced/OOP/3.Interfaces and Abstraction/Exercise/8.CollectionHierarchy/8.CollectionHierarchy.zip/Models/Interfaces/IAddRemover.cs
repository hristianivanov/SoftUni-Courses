﻿namespace CollectionHierarchy.Interfaces
{
    public interface IAddRemover : IAddder
    {
        string Remove();
    }
}
