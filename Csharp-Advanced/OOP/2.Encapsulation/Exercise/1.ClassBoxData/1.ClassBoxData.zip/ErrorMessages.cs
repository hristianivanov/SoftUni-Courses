﻿namespace _1.ClassBoxData
{
    public static class ErrorMessages
    {
        public const string VALUE_ZERO_OR_NEGATIVE = "{0} cannot be zero or negative.";
    }
}
