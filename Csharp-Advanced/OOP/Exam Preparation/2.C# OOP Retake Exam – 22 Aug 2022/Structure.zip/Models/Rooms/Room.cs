﻿using BookingApp.Models.Rooms.Contracts;
using BookingApp.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookingApp.Models.Rooms
{
    public abstract class Room : IRoom
    {
        private double pricePerNight;
        public int BedCapacity { get; private set; }
        public Room(int bedCapacity)
        {
            BedCapacity= bedCapacity;
            PricePerNight = 0;
        }
        /*o	PricePerNight cannot be negative. If so, throw new ArgumentException with message : "Price cannot be negative!". 
o	Set PricePerNight initial value to zero. 
*/

        public double PricePerNight
        {
            get => pricePerNight;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(string.Format(ExceptionMessages.PricePerNightNegative, value));
                }
            }
        }

        public void SetPrice(double price)
        {
            
        }
    }
}
