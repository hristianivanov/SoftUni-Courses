﻿namespace PlanetWars.Models.MilitaryUnits
{
    public class SpaceForces : MilitaryUnit
    {
        public SpaceForces(double cost) 
            : base(11)
        {
        }
    }
}
