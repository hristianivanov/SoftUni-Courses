﻿namespace Gym.Models.Gyms
{
    public class WeightliftingGym : Gym
    {
        public WeightliftingGym(string name) 
            : base(name, 20)
        {
        }
    }
}
