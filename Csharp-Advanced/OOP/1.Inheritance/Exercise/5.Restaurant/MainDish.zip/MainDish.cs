﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5.Restaurant
{
    public class MainDish : Food
    {
        public MainDish(string name, decimal price, double grams) : base(name, price, grams)
        {
        }
    }
}
