﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5.Restaurant
{
    public class HotBeverage : Beverage
    {
        public HotBeverage(string name, decimal price, double milliliters) : base(name, price, milliliters)
        {
        }
    }
}
