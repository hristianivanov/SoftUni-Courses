﻿namespace PlanetWars.Models.MilitaryUnits
{
    public class AnonymousImpactUnit : MilitaryUnit
    {
        public AnonymousImpactUnit() 
            : base(30)
        {
        }
    }
}
