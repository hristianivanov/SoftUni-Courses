﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2.Zoo
{
    public class Lizard : Reptile
    {
        public Lizard(string name) : base(name)
        {
        }
    }
}
