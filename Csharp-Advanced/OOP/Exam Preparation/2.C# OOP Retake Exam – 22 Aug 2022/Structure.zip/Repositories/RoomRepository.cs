﻿using BookingApp.Models.Rooms.Contracts;
using BookingApp.Repositories.Contracts;
using System.Collections.Generic;
using System.Linq;

namespace BookingApp.Repositories
{
    public class RoomRepository : IRepository<IRoom>
    {
        private List<IRoom> rooms;
        public RoomRepository()
        {
            rooms = new List<IRoom>();
        }
        public void AddNew(IRoom room)
        {
            rooms.Add(room);
        }

        public IReadOnlyCollection<IRoom> All()
            => rooms.AsReadOnly();

        public IRoom Select(string roomTypeName)
            => rooms.First(x => x.GetType().Name == roomTypeName);

    }
}
